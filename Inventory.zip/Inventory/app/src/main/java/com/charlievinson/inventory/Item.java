package com.charlievinson.inventory;

/*
 *  simple class representing inventory items with titles and counts, both represented as strings
 *
 *  item ids are used to track individual items in the database
 */
public class Item {
    private int id;
    private String title;
    private String count;
    public Item(int itemId, String itemTitle, String itemCount) {
        id = itemId;
        title = itemTitle;
        count = itemCount;
    }

    public int getId() {
        return id;
    }

    public void setId(int itemId) {
        this.id = itemId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String itemTitle) {
        this.title = itemTitle;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String itemCount) {
        this.count = itemCount;
    }
}