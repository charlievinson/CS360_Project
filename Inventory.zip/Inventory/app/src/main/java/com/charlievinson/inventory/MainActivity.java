package com.charlievinson.inventory;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    LoginDatabase db = new LoginDatabase(this); // initialize login database

    /*
     *  define buttons on this screen that are not created dynamically
     */
    Button newUserButton;
    Button currentUserButton;
    EditText usernameEditText;
    EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        /*
         *  change text in username EditText from "enter username" to blank when the user clicks on it
         */
        usernameEditText = (EditText) findViewById(R.id.username_edit_text);
        usernameEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                usernameEditText.setText("");
            }
        });

        /*
         *  change text in password EditText from "password" to blank when the user clicks on it
         */
        passwordEditText = (EditText) findViewById(R.id.password_edit_text);
        passwordEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                passwordEditText.setText("");
            }
        });

        /*
         *  handle current user button click
         */
        currentUserButton = (Button) findViewById(R.id.current_user_button);
        currentUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // get username and password text from appropriate EditTexts
                usernameEditText = findViewById(R.id.username_edit_text);
                passwordEditText = findViewById(R.id.password_edit_text);
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // check if user with matching username and password exists in the database
                if (db.getUser(username, password)) { // if so, start InventoryActivity
                    Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
                    startActivity(intent);
                } else { // otherwise, indicate that the user was not found
                    TextView loginErrorTextView = (TextView) findViewById(R.id.login_error_text);
                    loginErrorTextView.setText(R.string.login_not_found_text);
                }
            }
        });

        /*
         *  handle new user button click
         */
        newUserButton = (Button) findViewById(R.id.new_user_button);
        newUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // get username and password text from appropriate EditTexts
                usernameEditText = findViewById(R.id.username_edit_text);
                passwordEditText = findViewById(R.id.password_edit_text);
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // verify that a user with a matching username does not exist in the database and add to database
                if (db.addUser(username, password) != -1) { // if so, start InventoryActivity
                    Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
                    startActivity(intent);
                } else { // otherwise, indicate that the user already exists
                    TextView loginErrorTextView = (TextView) findViewById(R.id.login_error_text);
                    loginErrorTextView.setText(R.string.login_already_exists_text);
                }
            }
        });
    }
}