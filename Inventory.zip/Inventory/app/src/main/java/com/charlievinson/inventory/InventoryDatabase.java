package com.charlievinson.inventory;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {
    private static final String INVENTORY = "inventory.db";
    private static final int VERSION = 1;
    public List<Item> inventoryItems; //

    public InventoryDatabase(Context context) {
        super(context, INVENTORY, null, VERSION);
    }

    /*
     *  define database tables
     */
    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_TITLE =  "title";
        private static final String COL_COUNT = "count";
    }

    /*
     * called when database is created
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_TITLE + " text, " +
                InventoryTable.COL_COUNT + " text)");
    }

    /*
     *  called when database is upgraded to new version
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    /*
     *  function adds an item to the database
     *
     *  takes the inventory item title and count as parameters
     *
     *  returns an integer representing the next row in the database, which is used to define the
     *  next item id during runtime
     */
    public long addItem(String title, String count) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(InventoryTable.COL_TITLE, title); // add title to appropriate table
        values.put(InventoryTable.COL_COUNT, count); // add count to appropriate table

        long itemId = db.insert(InventoryTable.TABLE, null, values); // get next item id
        return itemId;
    }

    /*
     *  function removes an item from the database
     *
     *  takes the inventory item id as a parameter
     *
     *  returns true if any items were removed from the database, returns false otherwise
     */
    public boolean deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " = ?",
                new String[] { Long.toString(id) });
        return rowsDeleted > 0;
    }

    /*
    *
    *   These getItems() and getInventoryItems() functions are causing the app to crash when called during runtime to dynamically retrieve
    *   inventory items from the database. To temporarily work around this, items are added to an ArrayList that is
    *   used to update the UI with new inventory items.
    *
    */
    public void getItems() {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + InventoryDatabase.InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, new String[] {});

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String title = cursor.getString(1);
                String count = cursor.getString(2);
                Log.d(TAG, "item = " + id + ", " + title + ", " + count);
                Item item = new Item((int)id, title, count);
                inventoryItems.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    public List<Item> getInventoryItems() {
        return inventoryItems;
    }
}
