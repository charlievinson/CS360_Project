package com.charlievinson.inventory;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class LoginDatabase extends SQLiteOpenHelper {

    private static final String LOGIN = "login.db";
    private static final int VERSION = 1;

    public LoginDatabase(Context context) {
        super(context, LOGIN, null, VERSION);
    }

    /*
     *  define database tables
     */
    private static final class LoginTable {
        private static final String TABLE = "login";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    /*
     * called when database is created
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement, " +
                LoginTable.COL_USERNAME + " text, " +
                LoginTable.COL_PASSWORD + " text)");
    }

    /*
     *  called when database is upgraded to new version
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }

    /*
     *  function gets a user from the database
     *
     *  takes the user's username and password as parameters
     *
     *  searches the database for a value matching the user's username in the appropriate table.
     *  if the user exists and the value in the appropriate table matches the user's password,
     *  true is returned. returns false otherwise
     *
     *  called when the new user and current user buttons are clicked
     */
    public boolean getUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        // check for rows in the database with values matching the username in the appropriate table
        String sql = "select * from " + LoginTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{username});

        if (cursor.moveToFirst()) { // iterate through each row
            do {
                long id = cursor.getLong(0);
                String user = cursor.getString(1);
                String pass = cursor.getString(2);
                // check if usernames and password match provided values in current row
                if ((user.equals(username)) && (pass.equals(password))) {
                    return true;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return false;
    }

    /*
     *  function adds a new user to the database
     *
     *  takes the new user's username and password as parameters
     *
     *  verifies that that getUser() returns false (user does not currently exist in the database).
     *  if so, the username and password values are added to the appropriate tables and an integer
     *  representing the next row in the database is returned. otherwise, the user is not added to
     *  the database and the integer -1 is returned
     *
     *  called when the new user button is clicked
     */
    public long addUser(String username, String password) {

        if (!(getUser(username, password))) { // check if user exists in database
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(LoginTable.COL_USERNAME, username); // add username to appropriate table
            values.put(LoginTable.COL_PASSWORD, password); // add password to appropriate table

            long itemId = db.insert(LoginTable.TABLE, null, values); // get next user id
            return itemId;
        } else {
            return -1;
        }
    }
}
