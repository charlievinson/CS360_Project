package com.charlievinson.inventory;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.ToggleButton;

public class SettingsActivity extends AppCompatActivity {
    int toggleFlag = 1; // flag for toggle button to indicate whether it is on or off

    /*
     *  define buttons on this screen that are not created dynamically
     */
    ImageButton backButton;
    ToggleButton toggleButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        /*
         *  handle toggle button click
         */
        toggleButton = (ToggleButton) findViewById(R.id.toggle_button);
        toggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleFlag += 1; // increment flag
                String toastText; // create variable to hold text for toast
                int toastDuration = Toast.LENGTH_SHORT; // define toast length
                if (toggleFlag % 2 == 0) { // check flag and define toastText appropriately (even is on, odd is off)
                    toastText = "SMS notifications enabled";
                } else {
                    toastText = "SMS notifications disabled";
                }
                Toast.makeText(SettingsActivity.this, toastText, toastDuration).show(); // make toast
            }
        });

        /*
         *  handle back button click
         */
        backButton = (ImageButton) findViewById(R.id.settings_back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish(); // return to InventoryActivity
            }
        });
    }
}