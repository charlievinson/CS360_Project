package com.charlievinson.inventory;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    public int nextId = 1; // global id for assigning ids to new items
    InventoryDatabase db = new InventoryDatabase(this); // initialize inventory database

    /*
     *  define buttons on this screen that are not created dynamically
     */
    ImageButton settingsButton;
    FloatingActionButton newItemButton;

    /*
     *  ArrayLists track row elements that are created during runtime to be accessed later
     */
    public List<Item> inventoryDbItems = new ArrayList<>();
    public List<EditText> itemEditTexts = new ArrayList<>();
    public List<Button> subtractButtons = new ArrayList<>();
    public List<TextView> countTextViews = new ArrayList<>();
    public List<Button> addButtons = new ArrayList<>();
    public List<ImageButton> deleteButtons = new ArrayList<>();


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
         *
         *   The getItems() and getInventoryItems() functions of the InventoryDatabase class are causing the app
         *   to crash. To work around this, the UI is updated simply using an ArrayList inventoryDbItems that mimics the
         *   ArrayList inventoryItems that is used by the InventoryDatabase class.
         *
         */
        for (int i = 0; i < inventoryDbItems.size(); i++) {
            updateUI(inventoryDbItems.get(i).getTitle(), inventoryDbItems.get(i).getCount());
        }


        /*
         *   Set OnClickListener for each element in each row that is created dynamically
         */
        for (int i = 0; i < itemEditTexts.size(); i++) {
            Button currentSubtractButton = (Button) subtractButtons.get(i);
            Button currentAddButton = (Button) addButtons.get(i);
            ImageButton currentDeleteButton = (ImageButton) deleteButtons.get(i);
            int finalI = i;

            /*
             *  subtraction button OnClickListeners
             *
             *  updates count and UI, then removes item from database when appropriate
             */
            currentSubtractButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TextView currentCountTextView = countTextViews.get(finalI);
                    String currentCountString = currentCountTextView.getText().toString();
                    int currentCount = Integer.parseInt(currentCountString);
                    currentCount = currentCount - 1;

                    // handle item counts dropping to zero (stop displaying number after zero)
                    if (currentCount < 0) {
                        Item currentItem = inventoryDbItems.get(finalI);
                        int currentItemId = currentItem.getId();
                        db.deleteItem(currentItemId); // delete item from inventory database
                    // handle all other item counts
                    } else {
                        currentCountString = Integer.toString(currentCount);
                        currentCountTextView.setText(currentCountString);
                    }
                }
            });

            /*
             *  add button OnClickListeners
             *
             *  updates count and UI
             */
            currentAddButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TextView currentCountTextView = countTextViews.get(finalI);
                    String currentCountString = currentCountTextView.getText().toString();
                    int currentCount = Integer.parseInt(currentCountString);
                    currentCount = currentCount + 1;
                    currentCountString = Integer.toString(currentCount);
                    currentCountTextView.setText(currentCountString);

                }
            });

            /*
             *  delete button OnClickListeners
             *
             *  updates count and UI, then removes item from database
             */
            currentDeleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TextView currentCountTextView = countTextViews.get(finalI);
                    currentCountTextView.setText("0");

                    Item currentItem = inventoryDbItems.get(finalI);
                    int currentItemId = currentItem.getId();
                    db.deleteItem(currentItemId);
                }
            });

        }

        /*
         *  settings button OnClickListener and define image resource
         */
        settingsButton = (ImageButton) findViewById(R.id.settings_button);
        settingsButton.setImageResource(R.drawable.baseline_settings_24); // image resource
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // starts SettingsActivity
                Intent intent = new Intent(InventoryActivity.this,SettingsActivity.class);
                startActivity(intent);
            }
        });

        /*
         *  floating action button OnClickListener
         *
         *  creates new items and adds them to database (and currently inventoryDbItems), then updates the UI
         *  this function also dynamically sets the OnClickListener for each element in the new row that is created
         */
        newItemButton = (FloatingActionButton) findViewById(R.id.new_item_button);
        newItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // define text and count for new general inventory item
                String newItemTitle = "inventory item";
                String newItemCount = "1";

                nextId += db.addItem(newItemTitle, newItemCount); // add item to Inventory database and update next item id
                updateUI(newItemTitle, newItemCount); // update UI
                inventoryDbItems.add(new Item(nextId, newItemTitle, newItemCount)); // add item to inventoryDbItems

                /*
                 *   Set OnClickListener for each element in each row that is created dynamically
                 */
                for (int i = 0; i < itemEditTexts.size(); i++) {
                    Button currentSubtractButton = (Button) subtractButtons.get(i);
                    Button currentAddButton = (Button) addButtons.get(i);
                    ImageButton currentDeleteButton = (ImageButton) deleteButtons.get(i);
                    int finalI = i;

                    /*
                     *  subtraction button OnClickListeners
                     *
                     *  updates count and UI, then removes item from database when appropriate
                     */
                    currentSubtractButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            TextView currentCountTextView = countTextViews.get(finalI);
                            String currentCountString = currentCountTextView.getText().toString();
                            int currentCount = Integer.parseInt(currentCountString);
                            currentCount = currentCount - 1;
                            currentCountString = Integer.toString(currentCount);
                            currentCountTextView.setText(currentCountString);

                        }
                    });

                    /*
                     *  add button OnClickListeners
                     *
                     *  updates count and UI
                     */
                    currentAddButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            TextView currentCountTextView = countTextViews.get(finalI);
                            String currentCountString = currentCountTextView.getText().toString();
                            int currentCount = Integer.parseInt(currentCountString);
                            currentCount = currentCount + 1;
                            currentCountString = Integer.toString(currentCount);
                            currentCountTextView.setText(currentCountString);

                        }
                    });

                    /*
                     *  delete button OnClickListeners
                     *
                     *  updates count and UI, then removes item from database
                     */
                    currentDeleteButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            TextView currentCountTextView = countTextViews.get(finalI);
                            currentCountTextView.setText("0");

                            Item currentItem = inventoryDbItems.get(finalI);
                            int currentItemId = currentItem.getId();
                            db.deleteItem(currentItemId);
                        }
                    });
                }
            }
        });
    }

    /*
     *  function to dynamically create new UI elements and format them as rows contained in the main LinearLayout
     */
    public void updateUI(String title, String count) {

        LinearLayout mainLinearLayout = (LinearLayout) findViewById(R.id.inventory_item_list); // main linear layout (vertical)

        LinearLayout rowLinearLayout = new LinearLayout(this); // row linear layout currently being created (horizontal)
        LinearLayout rowLinearLayoutLeftHalf = new LinearLayout(this); // linear layout containing only single EditText element (horizontal)
        LinearLayout rowLinearLayoutRightHalf = new LinearLayout(this); // linear layout containing remaining elements (horizontal)

        // create inventory item EditText and add it to appropriate linear layout
        final EditText itemEditText = new EditText(this);
        int itemEditTextId = View.generateViewId();
        itemEditText.setId(itemEditTextId);
        itemEditText.setText(title);
        rowLinearLayoutLeftHalf.addView(itemEditText);
        itemEditTexts.add(itemEditText);

        // create subtract button and add it to appropriate linear layout
        final Button subtractButton = new Button(this);
        int subtractButtonId = View.generateViewId();
        subtractButton.setId(subtractButtonId);
        subtractButton.setText("-");
        rowLinearLayoutRightHalf.addView(subtractButton);
        subtractButtons.add(subtractButton);

        // create count TextView and add it to appropriate linear layout
        final TextView countTextView = new TextView(this);
        int countTextViewId = View.generateViewId();
        countTextView.setId(countTextViewId);
        countTextView.setText(count);
        rowLinearLayoutRightHalf.addView(countTextView);
        countTextViews.add(countTextView);

        // create add button and add it to appropriate linear layout
        final Button addButton = new Button(this);
        int addButtonId = View.generateViewId();
        addButton.setId(addButtonId);
        addButton.setText("+");
        rowLinearLayoutRightHalf.addView(addButton);
        addButtons.add(addButton);

        // create delete button and add it to appropriate linear layout
        final ImageButton deleteButton = new ImageButton(this);
        int deleteButtonId = View.generateViewId();
        deleteButton.setId(deleteButtonId);
        deleteButton.setImageResource(R.drawable.baseline_delete_24);
        rowLinearLayoutRightHalf.addView(deleteButton);
        deleteButtons.add(deleteButton);

        // construct row linear layout using predefined halves
        rowLinearLayout.addView(rowLinearLayoutLeftHalf);
        rowLinearLayout.addView(rowLinearLayoutRightHalf);

        // add row linear layout (horizontal) to main linear layout (vertical)
        mainLinearLayout.addView(rowLinearLayout);
    }
}